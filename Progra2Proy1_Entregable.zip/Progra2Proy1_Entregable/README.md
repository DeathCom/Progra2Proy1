# Progra2Proy1
Proyecto uno de progra dos de UAM

Proyecto #1
Debe construir una aplicaci�n utilizando programaci�n orientada a objetos, que nos permita
manejar los datos b�sicos de una biblioteca.
La aplicaci�n debe poder mantener en memoria los datos de los usuarios de la biblioteca, los
cuales pueden ser estudiantes, profesores o funcionarios de la Universidad.
Para esto debe crear una clase PERSONA que debe tener los datos como nombre, apellido,
direcci�n de correo, tel�fono y sede. De la clase PERSONA se derivan 4 diferentes sub-clases que
ser�n ESTUDIANTE, FUNCIONARIO, PROFESOR y AUTOR.
La clase ESTUDIANTE debe tener los daos de n�mero de carnet, carrera que est� cursando y un
estatus que indique si es estudiante activo (SI/NO). La clase FUNCIONARIO debe contener los
datos de n�mero de empleado, puesto y departamento. La clase PROFESOR debe contener los
datos de c�digo de marca, cantidad de cursos que imparte. La clase AUTOR debe contener los
datos de nacionalidad, un estatus que nos indique si el autor esta vivo y la cantidad de libros
publicados.
En la super clase PERSONA se deben implementar los m�todos get y set para todos los campos,
pero se debe declarar un m�todo abstracto que nos permita obtener la cantidad de libros
prestados que tiene cada persona.
Tambi�n se debe implementar una clase LIBRO que permita tener el registro de los libros que
posee la biblioteca y debe tener los datos nombre, autor, a�o de publicaci�n, editorial y cantidad
de libros que tiene la universidad y cantidad de libros que est�n disponibles.
Se debe implementar m�todos que nos permitan ingresar usuarios de todos los tipos, que nos
permitan crear libros y que nos permitan el pr�stamo y devoluci�n de libros.
La interface queda a libre elecci�n de su parte. Puede usar todo lo que usted conozca sobre
programaci�n, teniendo en cuenta que tendr� que explicar con detalle su c�digo y demostrar
que fue realizado por usted.
Para mantener los datos en memoria puede usar cualquier tipo de estructura que usted desee.
